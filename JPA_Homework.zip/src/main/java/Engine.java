import entities.Address;
import entities.Department;
import entities.Employee;
import entities.Project;

import javax.persistence.EntityManager;
import javax.persistence.Query;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Comparator;
import java.util.List;

public class Engine implements Runnable {

    private final EntityManager entityManager;
    private final BufferedReader reader;

    public Engine(EntityManager entityManager) {
        this.entityManager = entityManager;
        this.reader = new BufferedReader(new InputStreamReader(System.in));
    }

    public void run() {
        //Ex2
        //changeCasingEx2();

        //Ex3
//        try {
//            containsEmployeeEx3();
//        } catch (IOException e) {
//            e.printStackTrace();
//        }
        //Ex4
//        employeesWithSalaryOver50kEx4();

        //Ex5
        //employeesFromDepartmentEx5();

        //Ex6
//        try {
//            addNewAddressAndUpdateEmployeeEx6();
//        } catch (IOException e) {
//            e.printStackTrace();
//        }

        //Ex7
        //addressWithEmployeeCountEx7();

        //Ex8
//        try {
//            getEmployeeWithProject();
//        } catch (IOException e) {
//            e.printStackTrace();
//        }

        //Ex9
        //findLatestTenProjectsEx9();

        //Ex10
        //increaseSalariesEx10();

        //Ex11
//        try {
//            findEmployeesByFirstNameEx11();
//        } catch (IOException e) {
//            e.printStackTrace();
//        }

        //Ex12
      //  employeesMaxSalaryEx12();
    }

//    private void employeesMaxSalaryEx12() {
//        entityManager.createQuery("select max(e.salary), d.name from Employee e " +
//                        "join Department d " +
//                        "group by d.name " +
//                        "having max(e.salary) not in (30000, 70000)", Department.class)
//                .getResultStream()
//                .forEach(dep -> {
//                    System.out.printf("%s %.2f%n", dep.getName(), );
//                });
//    }

    private void findEmployeesByFirstNameEx11() throws IOException {
        System.out.println("Enter employee's part of the name:");
        String pattern = reader.readLine();
        entityManager.createQuery("select e from Employee e " +
                "where e.firstName like  concat(:pattern, '%') ", Employee.class)
                .setParameter("pattern", pattern)
                .getResultStream()
                .forEach(employee -> {
                    System.out.printf("%s %s - %s - ($%.2f)%n",
                            employee.getFirstName(), employee.getLastName(),
                            employee.getJobTitle(), employee.getSalary());
                });
    }

    private void increaseSalariesEx10() {
        entityManager.getTransaction().begin();
        entityManager.createQuery("update Employee e " +
                "set e.salary = e.salary * 1.12 " +
                "where e.department.id in (1, 2, 4, 11)")
                .executeUpdate();
        entityManager.getTransaction().commit();

        entityManager.createQuery("select e from Employee e " +
                "where e.department.name in ('Engineering', 'Tool Design', 'Marketing', 'Information Services')",
                Employee.class)
                .getResultStream()
                .forEach(employee -> {
                    System.out.printf("%s %s ($%.2f)%n", employee.getFirstName(),
                            employee.getLastName(), employee.getSalary());
                });

    }

    private void findLatestTenProjectsEx9() {
        List<Project> projects =
                entityManager.createQuery("select p from Project p " +
                        "order by p.startDate desc", Project.class)
                        .setMaxResults(10)
                        .getResultList();
        projects.stream().sorted(Comparator.comparing(Project::getName)).forEach(project -> {
            System.out.println("Project name: " + project.getName());
            System.out.println("\tProject Description: " + project.getDescription());
            System.out.println("\tProject Start Date: " + project.getStartDate());
            System.out.println("\tProject End Date: " + project.getEndDate());
        });
    }

    private void getEmployeeWithProjectEx8() throws IOException {
        System.out.println("Enter employee id:");
        int emplID = Integer.parseInt(reader.readLine());

        Employee employee =
                entityManager.find(Employee.class, emplID);
        System.out.printf("%s %s - %s%n", employee.getFirstName(), employee.getLastName(), employee.getJobTitle());
        employee.getProjects().stream().sorted(Comparator.comparing(Project::getName)).forEach(project -> {
            System.out.println("\t" + project.getName());
        });
    }

    private void addressWithEmployeeCountEx7() {
        entityManager.createQuery("select a from Address a " +
                "order by a.employees.size desc", Address.class)
                .setMaxResults(10)
                .getResultStream()
                .forEach(a -> {
                    System.out.printf("%s, %s - %d employees%n",
                            a.getText(), a.getTown().getName(),
                            a.getEmployees().size());
                });
    }

    private void addNewAddressAndUpdateEmployeeEx6() throws IOException {
        Address address = createNewAddress("Vitoshka 15");
        System.out.println("Enter last name of employee:");
        String nameToFind = reader.readLine();
        Employee employee = entityManager.createQuery("select e from Employee e " +
                "where e.lastName = :name", Employee.class)
                .setParameter("name", nameToFind)
                .getSingleResult();
        entityManager.getTransaction().begin();
        employee.setAddress(address);
        entityManager.getTransaction().commit();
    }

    private Address createNewAddress(String addressName) {
        Address address = new Address();
        address.setText(addressName);
        entityManager.getTransaction().begin();
        entityManager.persist(address);
        entityManager.getTransaction().commit();
        return address;
    }

    private void employeesFromDepartmentEx5() {
        entityManager.createQuery("select e from Employee e " +
                "where e.department.name = 'Research and Development' " +
                "order by e.salary, e.id", Employee.class)
                .getResultStream()
                .forEach(employee -> {
                    System.out.printf("%s %s from Research and Development - $%.2f%n",
                            employee.getFirstName(), employee.getLastName(), employee.getSalary());
                });
    }

    private void employeesWithSalaryOver50kEx4() {
        entityManager.createQuery(
                "select e from Employee e " +
                        "where e.salary > 50000", Employee.class)
                .getResultStream()
                .map(Employee::getFirstName)
                .forEach(System.out::println);

    }

    private void containsEmployeeEx3() throws IOException {
        System.out.println("Enter full name of employee:");
        String nameToFind = reader.readLine();
        List<Employee> employees = entityManager.createQuery(
                "select e from  Employee e " +
                        "where concat(e.firstName, ' ', e.lastName) = :name", Employee.class)
                .setParameter("name", nameToFind)
                .getResultList();
        System.out.println(employees.size() == 0 ? "No" : "Yes");
    }

    private void changeCasingEx2() {

        entityManager.getTransaction().begin();
        entityManager.createQuery("update Town t " +
                "set t.name = lower(t.name) " +
                "where length(t.name) <= 5 ")
                .executeUpdate();
        entityManager.getTransaction().commit();
    }
}
